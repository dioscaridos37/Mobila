package com.glass.dialer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var insT = 0f
    private var insB = 0f
    private fun applyInsets() = web.evaluateJavascript("window.setInsets&&setInsets($insT,$insB)", null)
    private val perms = arrayOf(
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.CALL_PHONE
    )

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0
        window.navigationBarColor = 0
        var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = f
        if (Build.VERSION.SDK_INT >= 28)
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        web = WebView(this)
        web.setBackgroundColor(0xFFEDF1F8.toInt())
        web.setOnApplyWindowInsetsListener { _, ins ->
            val d = resources.displayMetrics.density
            insT = ins.systemWindowInsetTop / d
            insB = ins.systemWindowInsetBottom / d
            applyInsets()
            ins
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) { applyInsets() }
        }
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        if (!perms.all { has(it) }) requestPermissions(perms, 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        web.evaluateJavascript("window.onPerms&&onPerms()", null)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.evaluateJavascript("window.onPerms&&onPerms()", null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun contacts(): String {
            val out = JSONArray()
            if (!has(Manifest.permission.READ_CONTACTS)) return "[]"
            val seen = HashSet<String>()
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val p = c.getString(1) ?: continue
                    if (seen.add(n + p.filter { it.isDigit() }))
                        out.put(JSONObject().put("n", n).put("p", p))
                }
            }
            return out.toString()
        }

        @JavascriptInterface
        fun calls(): String {
            val out = JSONArray()
            if (!has(Manifest.permission.READ_CALL_LOG)) return "[]"
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                    CallLog.Calls.TYPE, CallLog.Calls.DATE
                ), null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && out.length() < 200) {
                    out.put(
                        JSONObject().put("p", c.getString(0) ?: "")
                            .put("n", c.getString(1) ?: "")
                            .put("t", c.getInt(2)).put("d", c.getLong(3))
                    )
                }
            }
            return out.toString()
        }

        @JavascriptInterface
        fun call(n: String) {
            val uri = Uri.parse("tel:" + Uri.encode(n))
            val act = if (has(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
            startActivity(Intent(act, uri))
        }

        @JavascriptInterface
        fun haptic() {
            runOnUiThread { web.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
        }
    }
}
