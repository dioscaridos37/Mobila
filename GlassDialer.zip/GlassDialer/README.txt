Сборка: открой папку GlassDialer в Android Studio -> Sync -> Build > Build APK(s).
UI: app/src/main/assets/index.html (можно открыть в браузере, там тестовые данные).
Мост к системе: app/src/main/java/com/glass/dialer/MainActivity.kt
Разрешения запрашиваются при первом запуске: контакты, журнал, звонки.
Звонки через CALL_PHONE (без подтверждения системы), если отказать - откроется обычный набор.
